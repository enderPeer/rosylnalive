using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Text;

const string source = "// keep this comment\r\nclass C { int x = 0x2A; }\r\n";

var steps = new Dictionary<string, Action>(StringComparer.OrdinalIgnoreCase)
{
    ["tokenize"] = Tokenize,
    ["roundtrip"] = Roundtrip,
    ["rewrite"] = Rewrite,
    ["generate"] = Generate,
    ["incremental"] = Incremental,
    ["malformed"] = Malformed
};

var requested = args.Length == 0 ? steps.Keys.ToArray() : args;
foreach (var name in requested)
{
    if (!steps.TryGetValue(name, out var run))
        throw new ArgumentException($"Unknown step: {name}");
    Console.WriteLine($"== {name} ==");
    run();
}

void Tokenize()
{
    var tokens = SyntaxFactory.ParseTokens(source).ToArray();
    foreach (var token in tokens)
    {
        Console.WriteLine($"{token.Kind(),-25} Text={Quote(token.Text),-12} ValueText={Quote(token.ValueText)}");
        foreach (var trivia in token.LeadingTrivia)
            Console.WriteLine($"  leading {trivia.Kind()}: {Quote(trivia.ToFullString())}");
        foreach (var trivia in token.TrailingTrivia)
            Console.WriteLine($"  trailing {trivia.Kind()}: {Quote(trivia.ToFullString())}");
    }
    Check(string.Concat(tokens.Select(t => t.ToFullString())) == source,
        "Tokens plus all trivia reproduce the original source");
}

void Roundtrip()
{
    var root = CSharpSyntaxTree.ParseText(source).GetRoot();
    Check(root.ToFullString() == source, "Parsed root preserves exact source text");
    Check(!root.ContainsDiagnostics, "Valid source has no syntax diagnostics");
}

void Rewrite()
{
    var root = CSharpSyntaxTree.ParseText(source).GetRoot();
    var oldToken = root.DescendantTokens().Single(t => t.IsKind(SyntaxKind.NumericLiteralToken));
    var newToken = SyntaxFactory.Literal(43).WithTriviaFrom(oldToken);
    var rewritten = root.ReplaceToken(oldToken, newToken);
    var text = rewritten.ToFullString();
    Check(text == source.Replace("0x2A", "43", StringComparison.Ordinal),
        "Only the selected literal's spelling changed");
    Check(root.ToFullString() == source, "Original immutable root is unchanged");
    var reparsed = CSharpSyntaxTree.ParseText(text);
    Check(reparsed.GetRoot().ToFullString() == text, "Rewritten text round-trips exactly");
    Check(!reparsed.GetDiagnostics().Any(d => d.Severity == DiagnosticSeverity.Error),
        "Rewritten text has no syntax errors");
    Console.WriteLine(Quote(text));
}

void Generate()
{
    var statement = SyntaxFactory.ReturnStatement(
        SyntaxFactory.LiteralExpression(
            SyntaxKind.NumericLiteralExpression,
            SyntaxFactory.Literal(42)));
    Console.WriteLine($"Before formatting: {Quote(statement.ToFullString())}");
    var generated = statement.NormalizeWhitespace().ToFullString();
    Check(generated == "return 42;", "Generated and formatted statement has correct token boundaries");
    Check(!SyntaxFactory.ParseStatement(generated).ContainsDiagnostics,
        "Generated statement parses without syntax diagnostics");
    Console.WriteLine(generated);
}

void Incremental()
{
    var tree = CSharpSyntaxTree.ParseText(source);
    var originalText = tree.GetText();
    var position = source.IndexOf("0x2A", StringComparison.Ordinal);
    var changedText = originalText.WithChanges(new TextChange(new TextSpan(position, 4), "43"));
    var updatedTree = tree.WithChangedText(changedText);
    Check(updatedTree.GetRoot().ToFullString() == source.Replace("0x2A", "43", StringComparison.Ordinal),
        "Tree updated from changed text preserves exact edited text");
    Check(!updatedTree.GetDiagnostics().Any(d => d.Severity == DiagnosticSeverity.Error),
        "Incremental update has no syntax errors");
    Check(tree.GetRoot().ToFullString() == source, "Previous syntax tree is unchanged");
}

void Malformed()
{
    const string incomplete = "class C { int x = ;";
    var tree = CSharpSyntaxTree.ParseText(incomplete);
    var root = tree.GetRoot();
    Check(root.ToFullString() == incomplete, "Incomplete source round-trips exactly");
    Check(tree.GetDiagnostics().Any(), "Incomplete source carries diagnostics");
    Check(root.DescendantTokens().Any(t => t.IsMissing), "Parser inserted missing zero-width tokens");
    foreach (var token in root.DescendantTokens().Where(t => t.IsMissing))
        Console.WriteLine($"Missing {token.Kind()}, Text={Quote(token.Text)}, Span={token.Span}");
    foreach (var diagnostic in tree.GetDiagnostics())
        Console.WriteLine(diagnostic);
}

static string Quote(string value) => JsonSerializer.Serialize(value);

static void Check(bool condition, string description)
{
    if (!condition)
        throw new InvalidOperationException(description);
    Console.WriteLine($"PASS: {description}");
}
