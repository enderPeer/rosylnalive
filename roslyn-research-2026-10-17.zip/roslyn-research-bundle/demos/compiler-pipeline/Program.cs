using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

const string source = """
    public static class Demo
    {
        public static int Add(int a, int b) => a + b;
        public static int Run() => Add(2, 3);
    }
    """;

var tree = new Lazy<SyntaxTree>(() =>
    CSharpSyntaxTree.ParseText(source));

var compilation = new Lazy<CSharpCompilation>(() =>
    CSharpCompilation.Create(
        "DynamicDemo",
        syntaxTrees: new[] { tree.Value },
        references: new[]
        {
            MetadataReference.CreateFromFile(typeof(object).Assembly.Location)
        },
        options: new CSharpCompilationOptions(
            OutputKind.DynamicallyLinkedLibrary)));

var steps = new Dictionary<string, Action>(StringComparer.OrdinalIgnoreCase)
{
    ["parse"] = () =>
    {
        Console.WriteLine(tree.Value.GetRoot().Kind());
        PrintDiagnostics(tree.Value.GetDiagnostics());
    },

    ["symbols"] = () =>
    {
        var type = compilation.Value.GetTypeByMetadataName("Demo")!;
        foreach (var member in type.GetMembers())
            Console.WriteLine(member.ToDisplayString());
    },

    ["bind"] = () =>
    {
        var model = compilation.Value.GetSemanticModel(tree.Value);

        var call = tree.Value.GetRoot()
            .DescendantNodes()
            .OfType<InvocationExpressionSyntax>()
            .Single();

        var target = model.GetSymbolInfo(call).Symbol;
        Console.WriteLine($"Call resolves to: {target?.ToDisplayString()}");
    },

    ["diagnostics"] = () =>
        PrintDiagnostics(compilation.Value.GetDiagnostics()),

    ["emit"] = () =>
    {
        using var output = new MemoryStream();
        var result = compilation.Value.Emit(output);

        PrintDiagnostics(result.Diagnostics);
        if (!result.Success)
            throw new InvalidOperationException("Compilation failed.");

        File.WriteAllBytes("DynamicDemo.dll", output.ToArray());
        Console.WriteLine("Created DynamicDemo.dll");
    }
};

var requested = args.Length > 0
    ? args
    : new[] { "parse", "symbols", "bind", "diagnostics", "emit" };

foreach (var name in requested)
{
    if (!steps.TryGetValue(name, out var step))
        throw new ArgumentException($"Unknown step: {name}");

    Console.WriteLine($"Running: {name}");
    step();
}

static void PrintDiagnostics(IEnumerable<Diagnostic> diagnostics)
{
    foreach (var diagnostic in diagnostics)
        Console.WriteLine(diagnostic);
}
