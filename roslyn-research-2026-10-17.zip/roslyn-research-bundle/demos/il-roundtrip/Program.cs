using System.Buffers.Binary;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.Loader;
using ICSharpCode.Decompiler;
using ICSharpCode.Decompiler.CSharp;
using ICSharpCode.Decompiler.TypeSystem;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

const string source = """
    // Original source comment.
    public static class Demo
    {
        public static int Add(int a, int b) => a + b;
        public static int Run() => Add(2, 3);
    }
    """;
var outputDirectory = Path.Combine(Directory.GetCurrentDirectory(), "artifacts");
Directory.CreateDirectory(outputDirectory);
byte[] originalPe = Compile(source, "OriginalDemo");
string assemblyPath = Path.Combine(outputDirectory, "OriginalDemo.dll");
File.WriteAllBytes(assemblyPath, originalPe);
Inspect(originalPe);
Check("original Run()", Run(originalPe), 5);

var decompiler = new CSharpDecompiler(assemblyPath, new DecompilerSettings());
string reconstructedSource = decompiler.DecompileTypeAsString(new FullTypeName("Demo"));
File.WriteAllText(Path.Combine(outputDirectory, "reconstructed-source.txt"), reconstructedSource);
Console.WriteLine("Reconstructed C#:");
Console.WriteLine(reconstructedSource);
Check("decompiled + recompiled Run()", Run(Compile(reconstructedSource, "RecompiledDemo")), 5);
Console.WriteLine($"Exact source text preserved: {source == reconstructedSource}");

var root = CSharpSyntaxTree.ParseText(reconstructedSource).GetRoot();
var runMethod = root.DescendantNodes().OfType<MethodDeclarationSyntax>()
    .Single(m => m.Identifier.ValueText == "Run");
var oldLiteral = runMethod.DescendantNodes().OfType<LiteralExpressionSyntax>()
    .Single(l => l.Token.Value is int value && value == 2);
var newLiteral = SyntaxFactory.LiteralExpression(
    SyntaxKind.NumericLiteralExpression, SyntaxFactory.Literal(4)).WithTriviaFrom(oldLiteral);
string editedSource = root.ReplaceNode(oldLiteral, newLiteral).ToFullString();
File.WriteAllText(Path.Combine(outputDirectory, "edited-source.txt"), editedSource);
byte[] editedPe = Compile(editedSource, "EditedDemo");
File.WriteAllBytes(Path.Combine(outputDirectory, "EditedDemo.dll"), editedPe);
Check("decompiled + edited + recompiled Run()", Run(editedPe), 7);
Console.WriteLine("PASS: all round-trip checks");

static byte[] Compile(string source, string assemblyName)
{
    // Corelib suffices for this tiny example. Real projects need their complete reference set.
    var compilation = CSharpCompilation.Create(
        assemblyName,
        new[] { CSharpSyntaxTree.ParseText(source) },
        new[] { MetadataReference.CreateFromFile(typeof(object).Assembly.Location) },
        new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,
            optimizationLevel: OptimizationLevel.Release));
    using var pe = new MemoryStream();
    var result = compilation.Emit(pe);
    if (!result.Success)
        throw new InvalidOperationException(string.Join(Environment.NewLine, result.Diagnostics));
    return pe.ToArray();
}

static int Run(byte[] pe)
{
    var context = new AssemblyLoadContext(null, isCollectible: true);
    try
    {
        using var stream = new MemoryStream(pe);
        var assembly = context.LoadFromStream(stream);
        var method = assembly.GetType("Demo")!.GetMethod("Run")!;
        return (int)method.Invoke(null, null)!;
    }
    finally
    {
        // Unload is a request; actual collection happens later after references disappear.
        context.Unload();
    }
}

static void Inspect(byte[] pe)
{
    var context = new AssemblyLoadContext(null, isCollectible: true);
    try
    {
        using var stream = new MemoryStream(pe);
        var type = context.LoadFromStream(stream).GetType("Demo")!;
        var add = type.GetMethod("Add")!;
        byte[] addIl = add.GetMethodBody()!.GetILAsByteArray()!;
        Console.WriteLine($"Add IL bytes: {Convert.ToHexString(addIl)}");
        Check("Add Release IL", Convert.ToHexString(addIl), "0203582A");
        var run = type.GetMethod("Run")!;
        byte[] runIl = run.GetMethodBody()!.GetILAsByteArray()!;
        Console.WriteLine($"Run IL bytes: {Convert.ToHexString(runIl)}");
        // This bounded decoder handles only the authored Run method's instructions.
        bool sawCall = false;
        for (int offset = 0; offset < runIl.Length;)
        {
            int start = offset;
            byte opcode = runIl[offset++];
            switch (opcode)
            {
                case 0x18: Console.WriteLine($"IL_{start:X4}: ldc.i4.2"); break;
                case 0x19: Console.WriteLine($"IL_{start:X4}: ldc.i4.3"); break;
                case 0x2a: Console.WriteLine($"IL_{start:X4}: ret"); break;
                case 0x28:
                    if (offset + 4 > runIl.Length) throw new InvalidOperationException("Truncated operand");
                    int token = BinaryPrimitives.ReadInt32LittleEndian(runIl.AsSpan(offset, 4));
                    offset += 4;
                    var target = run.Module.ResolveMethod(token)!;
                    Console.WriteLine($"IL_{start:X4}: call 0x{token:X8} -> {target.DeclaringType!.Name}.{target.Name}");
                    sawCall = target == add;
                    break;
                default: throw new NotSupportedException($"Unexpected opcode: 0x{opcode:X2}");
            }
        }
        Check("Run call resolves to Demo.Add", sawCall, true);
    }
    finally { context.Unload(); }
}

static void Check<T>(string label, T actual, T expected)
{
    if (!EqualityComparer<T>.Default.Equals(actual, expected))
        throw new Exception($"{label}: expected {expected}, got {actual}");
    Console.WriteLine($"PASS: {label} = {actual}");
}
