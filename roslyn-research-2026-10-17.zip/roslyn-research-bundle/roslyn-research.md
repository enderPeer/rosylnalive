**Roslyn research notes — 17 October 2026**

A compact reference to the concepts, APIs, and executable experiments covered in this chat. Code fragments below illustrate individual operations; complete runnable examples are linked at the end.

**Roslyn and its model.** Roslyn is the open-source .NET compiler platform for C# and Visual Basic. It exposes the compiler's understanding of source and referenced assembly metadata through public APIs. Its main uses include compilation, analyzers, code fixes, refactoring, and source generation. [Official overview](https://learn.microsoft.com/en-us/dotnet/csharp/roslyn-sdk/)

| Model | What it represents |
| --- | --- |
| Syntax tree | Source structure, tokens, comments, and whitespace |
| Symbol | A declared or referenced type, method, property, parameter, or variable |
| Semantic model | Meaning within a source file: bindings, expression types, and related analysis |
| Compilation | Source trees, assembly references, compiler options, and compiler results |
| Workspace | Documents, projects, and solutions for larger analysis/refactoring tools |

**Graphs and reflection.** A tool can build a graph from symbols and relationships such as containment, inheritance, references, and calls. Roslyn does not provide a universally complete runtime execution graph. A direct call can resolve to a declared method, while virtual dispatch, delegates, and reflection can require further analysis to identify actual runtime targets.

Roslyn's `INamedTypeSymbol`, `IMethodSymbol`, and `IPropertySymbol` are analogous to reflection's `Type`, `MethodInfo`, and `PropertyInfo`, but they are not interchangeable. Symbols describe compiler concepts; runtime reflection can also invoke methods and access object values. Roslyn can inspect source and metadata without executing the target application. Reflection also supports metadata-only inspection through `MetadataLoadContext`. [Semantic model](https://learn.microsoft.com/en-us/dotnet/csharp/roslyn-sdk/work-with-semantics), [reflection](https://learn.microsoft.com/en-us/dotnet/fundamentals/reflection/overview)

For `typeof(Customer).GetMethod(methodName).Invoke(...)`, Roslyn resolves the reflection API calls but cannot generally determine the eventual target when `methodName` comes from runtime configuration. A missing static call edge does not prove that a method is unused.

**Calling pipeline operations dynamically.** Store callbacks in a `Dictionary<string, Action>` or use a `switch` to select operations from configuration, command-line arguments, or a UI. These are requests for compiler results: Roslyn computes prerequisites on demand and caches information. They are not independently reorderable internal compiler passes.

| Requested operation | Public API |
| --- | --- |
| Tokenize | `SyntaxFactory.ParseTokens(source)` |
| Parse | `CSharpSyntaxTree.ParseText(source)` |
| Establish compilation inputs | `CSharpCompilation.Create(...)` |
| Inspect declarations | `GetTypeByMetadataName(...)`, `GetDeclaredSymbol(...)` |
| Resolve names, calls, and expression types | `GetSemanticModel(tree)`, then `GetSymbolInfo(...)` / `GetTypeInfo(...)` |
| Inspect stage diagnostics | `GetParseDiagnostics()`, `GetDeclarationDiagnostics()`, `GetMethodBodyDiagnostics()` |
| Collect compiler diagnostics | `GetDiagnostics()` |
| Produce an assembly | `Emit(stream)` |

`GetDiagnostics()` excludes emit-only diagnostics: check `EmitResult.Success` and `EmitResult.Diagnostics`. Obtaining a semantic model does not eagerly analyze everything. Standalone compilation hosts must explicitly run analyzer/generator APIs when those are needed. Trees and compilations are immutable; retain the new objects returned by changes. [Compilation API](https://learn.microsoft.com/en-us/dotnet/api/microsoft.codeanalysis.compilation)

**Tokenization and source round-trips.** Tokens identify keywords, identifiers, literals, operators, and punctuation. `Text` preserves spelling; `ValueText` exposes decoded text. For example, `0x2A` has `Text == "0x2A"` and `ValueText == "42"`. Leading/trailing trivia preserve whitespace, comments, and directives.

```csharp
var tokens = SyntaxFactory.ParseTokens(source).ToArray();
var tree = CSharpSyntaxTree.ParseText(source);
var root = tree.GetRoot();
bool exactText = root.ToFullString() == source;
```

`ParseTokens` returns a lazy sequence of detached tokens. Tree-based `DescendantTokens()` provides parser context and parent nodes; contextual keywords and error recovery can make its results differ from standalone lexing. Use a parsed tree for reliable file locations. [Tokenization API](https://learn.microsoft.com/en-us/dotnet/api/microsoft.codeanalysis.csharp.syntaxfactory.parsetokens?view=roslyn-dotnet-4.7.0)

`ToFullString()` preserves all represented text. `ToString()` omits a node's outer trivia, not all internal whitespace/comments. EOF may own final trivia, so concatenating only token `Text` loses information. Malformed input still round-trips through missing, zero-width tokens and skipped-token trivia while reporting diagnostics. Character preservation is separate from preserving a file's encoding and BOM. [Syntax model](https://learn.microsoft.com/en-us/dotnet/csharp/roslyn-sdk/work-with-syntax)

For a focused edit, retain the original token's trivia:

```csharp
var oldToken = root.DescendantTokens()
    .Single(t => t.IsKind(SyntaxKind.NumericLiteralToken));
var newRoot = root.ReplaceToken(
    oldToken, SyntaxFactory.Literal(43).WithTriviaFrom(oldToken));
string editedSource = newRoot.ToFullString();
```

For editor-style text updates, use `tree.GetText().WithChanges(...)` followed by `tree.WithChangedText(nextText)`. Roslyn can reuse internal syntax data for small changes. Update the compilation with `ReplaceSyntaxTree` and obtain a semantic model for the new tree before querying its semantics. [Incremental parsing](https://learn.microsoft.com/en-us/dotnet/api/microsoft.codeanalysis.syntaxtree.withchangedtext?view=roslyn-dotnet-5.3.0)

**Code generation.** `SyntaxFactory` constructs nodes/tokens; `ParseExpression`, `ParseStatement`, and `ParseMemberDeclaration` can construct syntax from snippets. Rewriters and replacement APIs transform existing syntax. Serialization does not automatically supply separating whitespace: the tested factory-built return statement produced `return42;` before formatting and `return 42;` after `NormalizeWhitespace()`. Preserve existing trivia for exact edits; normalize newly generated syntax when formatting is wanted. Syntactic validity alone does not establish correct types or behavior. [Transformation APIs](https://learn.microsoft.com/en-us/dotnet/csharp/roslyn-sdk/get-started/syntax-transformation)

Source generators add generated source to a compilation. `Compilation.Emit()` instead produces a PE assembly containing IL and metadata. These are distinct forms of generation.

**IL emission and metadata tokens.** Source syntax tokens do not map one-to-one to IL instructions. Emission translates analyzed/lowered code into instructions and metadata. An opcode such as `call` can carry a metadata-token operand identifying its target. A regular table token such as `0x06000001` means MethodDef table, row 1, within its owning module. Tokens are not stable identifiers across rebuilds; string tokens refer to the user-string heap rather than a metadata-table row. [Metadata and IL](https://learn.microsoft.com/en-us/dotnet/standard/metadata-and-self-describing-components)

Our compiled `Run() => Add(2, 3)` produced:

```text
IL_0000: ldc.i4.2
IL_0001: ldc.i4.3
IL_0002: call 0x06000001 -> Demo.Add
IL_0007: ret
```

The dynamic execution path is `Compilation.Emit` → PE stream → `AssemblyLoadContext.LoadFromStream` → reflection invocation. `GetMethodBody().GetILAsByteArray()` returns one method's instruction bytes, not a complete DLL. Decode operands according to their opcodes, then resolve metadata tokens through the containing module's `ResolveMethod`, `ResolveType`, or `ResolveMember`; generic cases may require enclosing generic context. Locals, exception regions, and metadata also matter when reconstructing methods. [IL inspection](https://learn.microsoft.com/en-us/dotnet/api/system.reflection.methodbody.getilasbytearray?view=net-10.0)

**Round-tripping compiled code.** Roslyn does not decompile IL. ILSpy's `ICSharpCode.Decompiler` reconstructs C# that can be parsed, edited, and compiled again:

```csharp
var decompiler = new CSharpDecompiler(assemblyPath, new DecompilerSettings());
string reconstructed = decompiler.DecompileTypeAsString(new FullTypeName("Demo"));
var reconstructedTree = CSharpSyntaxTree.ParseText(reconstructed);
// Transform the tree, create/update a compilation, Emit, then load the new assembly.
```

This is a behavioral reconstruction, not exact recovery of source or assembly bytes. Decompiled output can require adjustments; behavior needs validation. Retain original source when exact text matters. Editing a reflection-returned IL byte array does not patch a running method. Use a new assembly/version for the demonstrated loop. A collectible load context's `Unload()` requests unloading after its references become unreachable. [ILSpy API](https://github.com/icsharpcode/ILSpy/wiki/Getting-Started-With-ICSharpCode.Decompiler)

For direct IL generation, use `System.Reflection.Emit.ILGenerator`; for modifying existing assemblies, Mono.Cecil is an alternative. These operations must account for references in the destination module rather than blindly copying token numbers. [ILGenerator](https://learn.microsoft.com/en-us/dotnet/api/system.reflection.emit.ilgenerator.emit?view=net-10.0), [Mono.Cecil](https://github.com/jbevain/cecil)

**Verified environment and experiments.** Windows x64; SDK `10.0.402`; installed .NET runtimes `10.0.13`; demo target `net10.0`; Roslyn package `5.9.0`; ILSpy package `11.1.0.9782`. SDK directory: `C:\Users\end\AppData\Local\Microsoft\dotnet`. User PATH and `DOTNET_ROOT` were configured; `dotnet` resolved normally after restarting Codex.

| Experiment | Observed result |
| --- | --- |
| Dynamically selected compiler operations | Parsing, symbols, binding, diagnostics, and DLL emission succeeded; binding alone also succeeded |
| Tokenization and source transformations | 15 checks passed, including exact trivia/CRLF preservation, focused edits, generation, incremental updates, and malformed input |
| IL inspection | `Add` bytes: `0203582A`; `Run` bytes: `181928010000062A`; decoded call resolved to `Demo.Add` |
| Decompiled and recompiled example | Original result `5`; reconstructed/recompiled result `5`; edited argument from `2` to `4` produced `7` |
| Source fidelity after decompilation | Not exact: original comment disappeared and expression bodies became blocks |

Runnable examples and their generated artifacts are included in this bundle. See README.md for run instructions:

- [Compiler pipeline demo](demos/compiler-pipeline/Program.cs)
- [Tokenization and source round-trip demo](demos/tokenization/Program.cs)
- [IL decompile/edit/recompile demo](demos/il-roundtrip/Program.cs)
