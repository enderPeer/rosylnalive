**Roslyn research bundle — 17 October 2026**

Start with [the research reference](roslyn-research.md). This bundle contains the notes, three runnable source projects, and the generated DLL/source artifacts from the experiments.

You need the **.NET 10 SDK**. The first run restores NuGet packages and needs network access unless they are already cached. Project files pin `Microsoft.CodeAnalysis.CSharp` to `5.9.0`; the IL round-trip project also pins `ICSharpCode.Decompiler` to `11.1.0.9782`.

Extract the ZIP, open a terminal in this folder, and run:

```shell
cd demos/compiler-pipeline
dotnet run

cd ../tokenization
dotnet run

cd ../il-roundtrip
dotnet run --configuration Release
```

The directory changes matter: the demos write their output into the current directory. Re-running them regenerates the included sample artifacts.

| Demo | What it demonstrates | Expected result |
| --- | --- | --- |
| [Compiler pipeline](demos/compiler-pipeline/Program.cs) | Runtime selection of parsing, symbols, binding, diagnostics, and emission | Call resolves to `Demo.Add(int, int)`; emits `DynamicDemo.dll` |
| [Tokenization](demos/tokenization/Program.cs) | Tokens/trivia, exact text preservation, edits, generation, incremental parsing, malformed input | 15 checks pass |
| [IL round-trip](demos/il-roundtrip/Program.cs) | Compile, inspect IL and metadata tokens, decompile, edit, recompile, execute | Results `5`, `5`, then `7`; source text is not preserved exactly |

Inside the compiler-pipeline directory, individual operations can be selected with `dotnet run -- symbols bind`. Inside the tokenization directory, try `dotnet run -- tokenize rewrite generate`. Its other modes are `roundtrip`, `incremental`, and `malformed`.

The IL example's instruction decoder is deliberately limited to the sample's opcodes. It is not a general IL disassembler. The compiler examples reference only core library types; larger programs need their complete framework and project references.

Generated IL artifacts are in [demos/il-roundtrip/artifacts](demos/il-roundtrip/artifacts). Reconstructed and edited source use `.txt` extensions so they are not accidentally compiled into the host project.

The bundle preserves source and experiment outputs. SDK installations, NuGet package caches, and rebuildable `bin`/`obj` directories are not included.
